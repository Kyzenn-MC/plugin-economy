package com.kyzen.economy;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Bảng nhỏ bên cạnh màn hình hiển thị số dư. */
final class Board {
    private final VndPlugin plugin;
    private final Map<UUID, Scoreboard> boards = new HashMap<>();

    Board(VndPlugin plugin) {
        this.plugin = plugin;
    }

    void show(Player p) {
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        boards.put(p.getUniqueId(), sb);
        p.setScoreboard(sb);
        update(p.getUniqueId());
    }

    void remove(UUID id) {
        boards.remove(id);
    }

    void update(UUID id) {
        Scoreboard sb = boards.get(id);
        Player p = Bukkit.getPlayer(id);
        if (sb == null || p == null) return;
        Objective o = sb.getObjective("vnd");
        if (o == null) {
            o = sb.registerNewObjective("vnd", Criteria.DUMMY,
                    VndPlugin.c(plugin.getConfig().getString("scoreboard-title", "&6&lVÍ TIỀN")));
            o.setDisplaySlot(DisplaySlot.SIDEBAR);
        }
        for (String e : new ArrayList<>(sb.getEntries())) sb.resetScores(e);
        o.getScore("§0 ").setScore(4);
        o.getScore("§eSố dư:").setScore(3);
        o.getScore("§a" + VndPlugin.fmt(plugin.eco.balance(id))).setScore(2);
        o.getScore("§1 ").setScore(1);
    }
}
