package com.kyzen.economy;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Lưu số dư (VND) và số lượng đã bán trong ngày. */
final class Economy {
    private final VndPlugin plugin;
    private final File file;
    private final Map<UUID, Long> bal = new HashMap<>();
    private final Map<UUID, Map<String, Integer>> sold = new HashMap<>();
    private String day = "";
    private boolean dirty;

    Economy(VndPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
        load();
        Bukkit.getScheduler().runTaskTimer(plugin, this::saveIfDirty, 6000L, 6000L);
    }

    private static String today() {
        return LocalDate.now().toString();
    }

    private void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection b = y.getConfigurationSection("balances");
        if (b != null) for (String k : b.getKeys(false)) bal.put(UUID.fromString(k), b.getLong(k));
        day = y.getString("day", today());
        ConfigurationSection s = y.getConfigurationSection("sold");
        if (s != null) {
            for (String u : s.getKeys(false)) {
                ConfigurationSection us = s.getConfigurationSection(u);
                if (us == null) continue;
                Map<String, Integer> m = new HashMap<>();
                for (String mat : us.getKeys(false)) m.put(mat, us.getInt(mat));
                sold.put(UUID.fromString(u), m);
            }
        }
        rollDay();
    }

    private void rollDay() {
        if (!today().equals(day)) {
            sold.clear();
            day = today();
            dirty = true;
        }
    }

    void init(UUID id) {
        if (!bal.containsKey(id)) {
            bal.put(id, plugin.getConfig().getLong("start-balance", 10000));
            dirty = true;
        }
    }

    long balance(UUID id) {
        return bal.getOrDefault(id, 0L);
    }

    void add(UUID id, long amount) {
        bal.merge(id, amount, Long::sum);
        changed(id);
    }

    boolean take(UUID id, long amount) {
        if (balance(id) < amount) return false;
        bal.put(id, balance(id) - amount);
        changed(id);
        return true;
    }

    void set(UUID id, long amount) {
        bal.put(id, Math.max(0, amount));
        changed(id);
    }

    private void changed(UUID id) {
        dirty = true;
        if (plugin.board != null) plugin.board.update(id);
    }

    int soldToday(UUID id, Material m) {
        rollDay();
        return sold.getOrDefault(id, Map.of()).getOrDefault(m.name(), 0);
    }

    void addSold(UUID id, Material m, int n) {
        rollDay();
        sold.computeIfAbsent(id, k -> new HashMap<>()).merge(m.name(), n, Integer::sum);
        dirty = true;
    }

    void saveIfDirty() {
        if (dirty) save();
    }

    void save() {
        YamlConfiguration y = new YamlConfiguration();
        bal.forEach((k, v) -> y.set("balances." + k, v));
        y.set("day", day);
        sold.forEach((u, m) -> m.forEach((mat, n) -> y.set("sold." + u + "." + mat, n)));
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
            dirty = false;
        } catch (IOException e) {
            plugin.getLogger().severe("Không lưu được data.yml: " + e.getMessage());
        }
    }
}
