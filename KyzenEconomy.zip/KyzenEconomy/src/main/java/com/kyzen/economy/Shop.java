package com.kyzen.economy;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import static com.kyzen.economy.VndPlugin.c;
import static com.kyzen.economy.VndPlugin.fmt;

/** /shop: chỉ MUA đồ cơ bản, nhưng BÁN được rất nhiều thứ (có giảm giá khi bán quá nhiều). */
final class Shop implements Listener {
    private static final int PAGE = 45;

    private final VndPlugin plugin;
    private final Map<Material, Long> buy = new LinkedHashMap<>();
    private final Map<Material, Long> sell = new LinkedHashMap<>();

    Shop(VndPlugin plugin) {
        this.plugin = plugin;
        read("buy", buy);
        read("sell", sell);
    }

    private void read(String path, Map<Material, Long> out) {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection(path);
        if (s == null) return;
        for (String k : s.getKeys(false)) {
            Material m = Material.matchMaterial(k);
            if (m == null || m.isAir() || !m.isItem()) {
                plugin.getLogger().warning("Bỏ qua vật phẩm không hợp lệ trong '" + path + "': " + k);
                continue;
            }
            long v = s.getLong(k);
            if (v > 0) out.put(m, v);
        }
    }

    static final class Holder implements InventoryHolder {
        boolean buyMode;
        int page;
        final List<Map.Entry<Material, Long>> entries;
        Inventory inv;

        Holder(boolean buyMode, int page, List<Map.Entry<Material, Long>> entries) {
            this.buyMode = buyMode;
            this.page = page;
            this.entries = entries;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    void open(Player p, boolean buyMode, int page) {
        List<Map.Entry<Material, Long>> entries = new ArrayList<>((buyMode ? buy : sell).entrySet());
        Holder h = new Holder(buyMode, page, entries);
        h.inv = Bukkit.createInventory(h, 54,
                c(buyMode ? "&2&lCỬA HÀNG - MUA" : "&6&lCỬA HÀNG - BÁN"));
        render(p, h);
        p.openInventory(h.inv);
    }

    private void render(Player p, Holder h) {
        int pages = Math.max(1, (h.entries.size() + PAGE - 1) / PAGE);
        h.page = Math.max(0, Math.min(h.page, pages - 1));
        Inventory inv = h.inv;
        inv.clear();
        UUID id = p.getUniqueId();

        for (int i = 0; i < PAGE; i++) {
            int idx = h.page * PAGE + i;
            if (idx >= h.entries.size()) break;
            Map.Entry<Material, Long> e = h.entries.get(idx);
            Material m = e.getKey();
            long price = e.getValue();
            ItemStack it = new ItemStack(m);
            ItemMeta meta = it.getItemMeta();
            List<Component> lore = new ArrayList<>();
            if (h.buyMode) {
                lore.add(c("&7Giá mua: &a" + fmt(price) + " &7/ cái"));
                lore.add(c(""));
                lore.add(c("&eChuột trái: &fmua 1"));
                lore.add(c("&eChuột phải: &fmua 16"));
                lore.add(c("&eShift + trái: &fmua 64"));
            } else {
                lore.add(c("&7Giá gốc: &a" + fmt(price) + " &7/ cái"));
                lore.add(c("&7Giá hiện tại: &a" + fmt(quote(id, m, price, 1))));
                lore.add(c("&7Hôm nay đã bán: &f" + plugin.eco.soldToday(id, m)));
                lore.add(c(""));
                lore.add(c("&eChuột trái: &fbán 1"));
                lore.add(c("&eChuột phải: &fbán 16"));
                lore.add(c("&eShift + trái: &fbán tất cả"));
            }
            meta.lore(lore);
            it.setItemMeta(meta);
            inv.setItem(i, it);
        }

        ItemStack pane = VndPlugin.icon(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 45; i < 54; i++) inv.setItem(i, pane);
        if (h.page > 0) inv.setItem(45, VndPlugin.icon(Material.ARROW, "&eTrang trước"));
        if (h.page < pages - 1) inv.setItem(53, VndPlugin.icon(Material.ARROW, "&eTrang sau"));
        inv.setItem(48, VndPlugin.icon(Material.GOLD_INGOT, "&6Số dư: &a" + fmt(plugin.eco.balance(id)),
                "&7Trang " + (h.page + 1) + "/" + pages));
        inv.setItem(49, h.buyMode
                ? VndPlugin.icon(Material.EMERALD, "&aChuyển sang BÁN đồ", "&7Hoặc dùng /sell hand, /sell all")
                : VndPlugin.icon(Material.CHEST, "&aChuyển sang MUA đồ"));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;

        int slot = e.getRawSlot();
        if (slot == 45 && h.page > 0) {
            h.page--;
            render(p, h);
            return;
        }
        if (slot == 53) {
            h.page++;
            render(p, h);
            return;
        }
        if (slot == 49) {
            open(p, !h.buyMode, 0);
            return;
        }
        if (slot < 0 || slot >= PAGE) return;
        int idx = h.page * PAGE + slot;
        if (idx >= h.entries.size()) return;

        Map.Entry<Material, Long> en = h.entries.get(idx);
        ClickType ct = e.getClick();
        if (h.buyMode) {
            int q = ct.isShiftClick() ? 64 : ct.isRightClick() ? 16 : 1;
            buy(p, en.getKey(), en.getValue(), q);
        } else {
            int q = ct.isShiftClick() ? Integer.MAX_VALUE : ct.isRightClick() ? 16 : 1;
            long[] r = doSell(p, en.getKey(), q);
            report(p, en.getKey(), r);
        }
        render(p, h);
    }

    private void buy(Player p, Material m, long price, int q) {
        long total = price * q;
        if (!plugin.eco.take(p.getUniqueId(), total)) {
            p.sendMessage(c("&cKhông đủ tiền! Cần &e" + fmt(total)));
            return;
        }
        for (ItemStack left : p.getInventory().addItem(new ItemStack(m, q)).values())
            p.getWorld().dropItemNaturally(p.getLocation(), left);
        p.sendMessage(c("&aĐã mua &fx" + q + " ").append(VndPlugin.name(m)).append(c(" &a(-" + fmt(total) + ")")));
    }

    private static boolean plain(ItemStack it, Material m) {
        return it != null && it.getType() == m && !it.hasItemMeta();
    }

    /** Giá bán n cái: X cái đầu 100%, X tiếp theo 50%, còn lại 20% (theo từng ngày). */
    private long quote(UUID id, Material m, long base, int n) {
        int q = plugin.getConfig().getInt("sell-full-price-quota", 128);
        int s = plugin.eco.soldToday(id, m);
        long total = 0;
        for (int i = 0; i < n; i++) {
            int c = s + i;
            double mult = c < q ? 1.0 : c < 2 * q ? 0.5 : 0.2;
            total += Math.max(1, (long) Math.floor(base * mult));
        }
        return total;
    }

    /** @return {số lượng đã bán, tiền nhận được} */
    private long[] doSell(Player p, Material m, int max) {
        Long base = sell.get(m);
        if (base == null) return new long[]{0, 0};
        ItemStack[] c = p.getInventory().getStorageContents();
        int have = 0;
        for (ItemStack it : c) if (plain(it, m)) have += it.getAmount();
        int n = Math.min(have, max);
        if (n <= 0) return new long[]{0, 0};

        long total = quote(p.getUniqueId(), m, base, n);
        int left = n;
        for (int i = 0; i < c.length && left > 0; i++) {
            if (!plain(c[i], m)) continue;
            int take = Math.min(left, c[i].getAmount());
            if (take == c[i].getAmount()) c[i] = null;
            else c[i].setAmount(c[i].getAmount() - take);
            left -= take;
        }
        p.getInventory().setStorageContents(c);
        plugin.eco.add(p.getUniqueId(), total);
        plugin.eco.addSold(p.getUniqueId(), m, n);
        return new long[]{n, total};
    }

    private void report(Player p, Material m, long[] r) {
        if (r[0] <= 0) {
            p.sendMessage(c("&cBạn không có món này để bán (đồ đã đổi tên/enchant không bán được)."));
            return;
        }
        p.sendMessage(c("&aĐã bán &fx" + r[0] + " ").append(VndPlugin.name(m)).append(c(" &a(+" + fmt(r[1]) + ")")));
    }

    void sellHand(Player p) {
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType().isAir() || !sell.containsKey(hand.getType())) {
            p.sendMessage(c("&cMón đang cầm không bán được ở shop."));
            return;
        }
        report(p, hand.getType(), doSell(p, hand.getType(), hand.getAmount()));
    }

    void sellAll(Player p) {
        Set<Material> mats = new LinkedHashSet<>();
        for (ItemStack it : p.getInventory().getStorageContents())
            if (it != null && !it.hasItemMeta() && sell.containsKey(it.getType())) mats.add(it.getType());
        if (mats.isEmpty()) {
            p.sendMessage(c("&cKhông có món nào bán được trong túi."));
            return;
        }
        long total = 0, count = 0;
        for (Material m : mats) {
            long[] r = doSell(p, m, Integer.MAX_VALUE);
            count += r[0];
            total += r[1];
        }
        p.sendMessage(c("&aĐã bán &f" + count + " &avật phẩm, nhận &e" + fmt(total)));
    }
}
