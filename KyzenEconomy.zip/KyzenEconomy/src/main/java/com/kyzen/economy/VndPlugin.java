package com.kyzen.economy;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class VndPlugin extends JavaPlugin implements Listener {
    Economy eco;
    Board board;
    Shop shop;
    Auction ah;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        eco = new Economy(this);
        board = new Board(this);
        shop = new Shop(this);
        ah = new Auction(this);
        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(shop, this);
        getServer().getPluginManager().registerEvents(ah, this);
        for (Player p : Bukkit.getOnlinePlayers()) setup(p);
    }

    @Override
    public void onDisable() {
        if (eco != null) eco.save();
        if (ah != null) ah.save();
    }

    private void setup(Player p) {
        eco.init(p.getUniqueId());
        board.show(p);
        ah.deliver(p);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        setup(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        board.remove(e.getPlayer().getUniqueId());
    }

    // ---------- Tiện ích ----------
    static Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s)
                .decoration(TextDecoration.ITALIC, false);
    }

    static Component name(Material m) {
        return Component.translatable(m.translationKey());
    }

    static String fmt(long v) {
        return String.format(Locale.ROOT, "%,d", v).replace(',', '.') + "đ";
    }

    static ItemStack icon(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(c(name));
        List<Component> l = new ArrayList<>();
        for (String s : lore) l.add(c(s));
        if (!l.isEmpty()) meta.lore(l);
        it.setItemMeta(meta);
        return it;
    }

    /** Hỗ trợ: 5000, 5.000, 5k, 2.5k, 1m. Trả -1 nếu sai. */
    static long parseAmount(String s) {
        try {
            s = s.toLowerCase(Locale.ROOT).replace(",", "").replace("_", "");
            double v;
            if (s.endsWith("k")) v = Double.parseDouble(s.substring(0, s.length() - 1)) * 1_000;
            else if (s.endsWith("m")) v = Double.parseDouble(s.substring(0, s.length() - 1)) * 1_000_000;
            else v = Long.parseLong(s.replace(".", ""));
            if (v < 0 || v > 1e12) return -1;
            return (long) v;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    // ---------- Lệnh ----------
    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);

        if (n.equals("eco")) return eco(s, a);

        if (!(s instanceof Player p)) {
            s.sendMessage("Lệnh này chỉ dành cho người chơi.");
            return true;
        }

        switch (n) {
            case "balance" -> p.sendMessage(c("&eSố dư của bạn: &a" + fmt(eco.balance(p.getUniqueId()))));
            case "pay" -> pay(p, a);
            case "shop" -> shop.open(p, true, 0);
            case "sell" -> {
                if (a.length == 1 && a[0].equalsIgnoreCase("hand")) shop.sellHand(p);
                else if (a.length == 1 && a[0].equalsIgnoreCase("all")) shop.sellAll(p);
                else p.sendMessage(c("&cDùng: /sell hand &7(bán món đang cầm) &c| /sell all &7(bán mọi thứ bán được)"));
            }
            case "ah" -> {
                if (a.length == 0) ah.open(p, 0);
                else if (a[0].equalsIgnoreCase("sell") && a.length == 2) ah.list(p, a[1]);
                else p.sendMessage(c("&cDùng: /ah &7(mở chợ) &c| /ah sell <giá> &7(đăng bán món đang cầm)"));
            }
            default -> {
                return false;
            }
        }
        return true;
    }

    private void pay(Player p, String[] a) {
        if (a.length < 2) {
            p.sendMessage(c("&cDùng: /pay <tên> <số tiền>"));
            return;
        }
        Player t = Bukkit.getPlayerExact(a[0]);
        if (t == null) {
            p.sendMessage(c("&cNgười chơi không online."));
            return;
        }
        if (t.equals(p)) {
            p.sendMessage(c("&cBạn không thể tự chuyển tiền cho mình."));
            return;
        }
        long amt = parseAmount(a[1]);
        if (amt <= 0) {
            p.sendMessage(c("&cSố tiền không hợp lệ."));
            return;
        }
        if (!eco.take(p.getUniqueId(), amt)) {
            p.sendMessage(c("&cBạn không đủ tiền."));
            return;
        }
        eco.add(t.getUniqueId(), amt);
        p.sendMessage(c("&aĐã chuyển &e" + fmt(amt) + " &acho &f" + t.getName()));
        t.sendMessage(c("&aBạn nhận được &e" + fmt(amt) + " &atừ &f" + p.getName()));
    }

    private boolean eco(CommandSender s, String[] a) {
        if (!s.hasPermission("kyzen.eco.admin")) {
            s.sendMessage(c("&cBạn không có quyền."));
            return true;
        }
        if (a.length < 3) {
            s.sendMessage(c("&cDùng: /eco <give|take|set> <tên> <số tiền>"));
            return true;
        }
        OfflinePlayer t = Bukkit.getPlayerExact(a[1]);
        if (t == null) t = Bukkit.getOfflinePlayerIfCached(a[1]);
        if (t == null) {
            s.sendMessage(c("&cKhông tìm thấy người chơi."));
            return true;
        }
        long amt = parseAmount(a[2]);
        if (amt < 0) {
            s.sendMessage(c("&cSố tiền không hợp lệ."));
            return true;
        }
        var id = t.getUniqueId();
        eco.init(id);
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "give" -> eco.add(id, amt);
            case "take" -> eco.set(id, eco.balance(id) - amt);
            case "set" -> eco.set(id, amt);
            default -> {
                s.sendMessage(c("&cDùng: /eco <give|take|set> <tên> <số tiền>"));
                return true;
            }
        }
        s.sendMessage(c("&aSố dư mới của &f" + a[1] + "&a: &e" + fmt(eco.balance(id))));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String alias, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        if ((n.equals("pay") && a.length == 1) || (n.equals("eco") && a.length == 2)) {
            for (Player p : Bukkit.getOnlinePlayers())
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(a[a.length - 1].toLowerCase(Locale.ROOT)))
                    out.add(p.getName());
        } else if (n.equals("eco") && a.length == 1) out.addAll(List.of("give", "take", "set"));
        else if (n.equals("ah") && a.length == 1) out.add("sell");
        else if (n.equals("sell") && a.length == 1) out.addAll(List.of("hand", "all"));
        return out;
    }
}
