package com.kyzen.economy;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.kyzen.economy.VndPlugin.c;
import static com.kyzen.economy.VndPlugin.fmt;

/** /ah: chợ người chơi. Có phí chợ (đốt tiền) để chống lạm phát. */
final class Auction implements Listener {
    private static final int PAGE = 45;

    record Listing(long id, UUID seller, String sellerName, long price, ItemStack item, long expires) {
    }

    static final class Holder implements InventoryHolder {
        int page;
        List<Listing> view = new ArrayList<>();
        Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private final VndPlugin plugin;
    private final File file;
    private final LinkedHashMap<Long, Listing> listings = new LinkedHashMap<>();
    private final Map<UUID, List<ItemStack>> returns = new HashMap<>();
    private long nextId = 1;

    Auction(VndPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "ah.yml");
        load();
        Bukkit.getScheduler().runTaskTimer(plugin, this::expire, 1200L, 1200L);
    }

    // ---------- Lưu / tải ----------
    private void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        nextId = y.getLong("next-id", 1);
        ConfigurationSection ls = y.getConfigurationSection("listings");
        if (ls != null) {
            for (String k : ls.getKeys(false)) {
                ConfigurationSection s = ls.getConfigurationSection(k);
                if (s == null) continue;
                ItemStack it = s.getItemStack("item");
                String seller = s.getString("seller");
                if (it == null || seller == null) continue;
                long id = Long.parseLong(k);
                listings.put(id, new Listing(id, UUID.fromString(seller), s.getString("seller-name", "?"),
                        s.getLong("price"), it, s.getLong("expires")));
            }
        }
        ConfigurationSection rs = y.getConfigurationSection("returns");
        if (rs != null) {
            for (String k : rs.getKeys(false)) {
                List<ItemStack> l = new ArrayList<>();
                for (Object o : rs.getList(k, List.of())) if (o instanceof ItemStack i) l.add(i);
                if (!l.isEmpty()) returns.put(UUID.fromString(k), l);
            }
        }
    }

    void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("next-id", nextId);
        for (Listing l : listings.values()) {
            String p = "listings." + l.id();
            y.set(p + ".seller", l.seller().toString());
            y.set(p + ".seller-name", l.sellerName());
            y.set(p + ".price", l.price());
            y.set(p + ".expires", l.expires());
            y.set(p + ".item", l.item());
        }
        returns.forEach((u, l) -> y.set("returns." + u, l));
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Không lưu được ah.yml: " + e.getMessage());
        }
    }

    // ---------- Đăng bán ----------
    void list(Player p, String priceStr) {
        long price = VndPlugin.parseAmount(priceStr);
        long min = plugin.getConfig().getLong("ah.min-price", 100);
        long max = plugin.getConfig().getLong("ah.max-price", 1_000_000_000L);
        if (price < min || price > max) {
            p.sendMessage(c("&cGiá phải từ &e" + fmt(min) + " &cđến &e" + fmt(max) + "&c."));
            return;
        }
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType().isAir()) {
            p.sendMessage(c("&cHãy cầm món đồ muốn bán trên tay."));
            return;
        }
        long mine = listings.values().stream().filter(l -> l.seller().equals(p.getUniqueId())).count();
        int limit = plugin.getConfig().getInt("ah.max-listings", 7);
        if (mine >= limit) {
            p.sendMessage(c("&cBạn chỉ được đăng tối đa &e" + limit + " &cmón cùng lúc."));
            return;
        }
        long hours = plugin.getConfig().getLong("ah.expire-hours", 48);
        Listing l = new Listing(nextId++, p.getUniqueId(), p.getName(), price, hand.clone(),
                System.currentTimeMillis() + hours * 3_600_000L);
        listings.put(l.id(), l);
        p.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
        save();
        int tax = plugin.getConfig().getInt("ah.tax-percent", 5);
        p.sendMessage(c("&aĐã đăng bán &fx" + l.item().getAmount() + " &avới giá &e" + fmt(price)
                + " &7(phí chợ " + tax + "% khi bán được, hết hạn sau " + hours + " giờ)"));
    }

    // ---------- Giao đồ trả lại / hết hạn ----------
    void deliver(Player p) {
        List<ItemStack> l = returns.get(p.getUniqueId());
        if (l == null || l.isEmpty()) return;
        List<ItemStack> rest = new ArrayList<>();
        int given = l.size();
        for (ItemStack it : l) rest.addAll(p.getInventory().addItem(it).values());
        if (rest.isEmpty()) returns.remove(p.getUniqueId());
        else returns.put(p.getUniqueId(), rest);
        save();
        p.sendMessage(c("&aBạn nhận lại &f" + (given - rest.size()) + " &avật phẩm từ chợ (hết hạn/hủy)."));
        if (!rest.isEmpty()) p.sendMessage(c("&eTúi đầy! Còn " + rest.size() + " món sẽ trả ở lần mở /ah tiếp theo."));
    }

    private void expire() {
        long now = System.currentTimeMillis();
        boolean changed = false;
        Iterator<Listing> it = listings.values().iterator();
        while (it.hasNext()) {
            Listing l = it.next();
            if (l.expires() > now) continue;
            it.remove();
            returns.computeIfAbsent(l.seller(), k -> new ArrayList<>()).add(l.item());
            changed = true;
            Player p = Bukkit.getPlayer(l.seller());
            if (p != null) deliver(p);
        }
        if (changed) save();
    }

    // ---------- Giao diện ----------
    void open(Player p, int page) {
        deliver(p);
        Holder h = new Holder();
        h.page = page;
        h.inv = Bukkit.createInventory(h, 54, c("&5&lCHỢ NGƯỜI CHƠI"));
        render(p, h);
        p.openInventory(h.inv);
    }

    private void render(Player p, Holder h) {
        h.view = new ArrayList<>(listings.values());
        Collections.reverse(h.view); // mới nhất trước
        int pages = Math.max(1, (h.view.size() + PAGE - 1) / PAGE);
        h.page = Math.max(0, Math.min(h.page, pages - 1));
        Inventory inv = h.inv;
        inv.clear();
        long now = System.currentTimeMillis();

        for (int i = 0; i < PAGE; i++) {
            int idx = h.page * PAGE + i;
            if (idx >= h.view.size()) break;
            Listing l = h.view.get(idx);
            ItemStack it = l.item().clone();
            ItemMeta meta = it.getItemMeta();
            List<Component> lore = new ArrayList<>();
            if (meta.lore() != null) lore.addAll(meta.lore());
            long left = Math.max(0, (l.expires() - now) / 3_600_000L);
            lore.add(c(""));
            lore.add(c("&7Giá: &a" + fmt(l.price())));
            lore.add(c("&7Người bán: &f" + l.sellerName()));
            lore.add(c("&7Còn lại: &f" + left + " giờ"));
            lore.add(c(l.seller().equals(p.getUniqueId()) ? "&cClick để HỦY bán (nhận lại đồ)" : "&eClick để MUA"));
            meta.lore(lore);
            it.setItemMeta(meta);
            inv.setItem(i, it);
        }

        ItemStack pane = VndPlugin.icon(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 45; i < 54; i++) inv.setItem(i, pane);
        if (h.page > 0) inv.setItem(45, VndPlugin.icon(Material.ARROW, "&eTrang trước"));
        if (h.page < pages - 1) inv.setItem(53, VndPlugin.icon(Material.ARROW, "&eTrang sau"));
        inv.setItem(48, VndPlugin.icon(Material.GOLD_INGOT, "&6Số dư: &a" + fmt(plugin.eco.balance(p.getUniqueId())),
                "&7Trang " + (h.page + 1) + "/" + pages));
        inv.setItem(50, VndPlugin.icon(Material.PAPER, "&aĐăng bán",
                "&7Cầm món đồ trên tay rồi gõ:", "&f/ah sell <giá>",
                "&7Phí chợ: " + plugin.getConfig().getInt("ah.tax-percent", 5) + "%"));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;

        int slot = e.getRawSlot();
        if (slot == 45 && h.page > 0) {
            h.page--;
            render(p, h);
            return;
        }
        if (slot == 53) {
            h.page++;
            render(p, h);
            return;
        }
        if (slot < 0 || slot >= PAGE) return;
        int idx = h.page * PAGE + slot;
        if (idx >= h.view.size()) return;
        Listing l = h.view.get(idx);

        if (!listings.containsKey(l.id())) {
            p.sendMessage(c("&cMón này đã được mua hoặc bị hủy."));
            render(p, h);
            return;
        }

        if (l.seller().equals(p.getUniqueId())) {
            listings.remove(l.id());
            give(p, l.item().clone());
            save();
            p.sendMessage(c("&aĐã hủy bán và nhận lại vật phẩm."));
            render(p, h);
            return;
        }

        if (!plugin.eco.take(p.getUniqueId(), l.price())) {
            p.sendMessage(c("&cBạn không đủ tiền! Cần &e" + fmt(l.price())));
            return;
        }
        listings.remove(l.id());
        int taxPct = plugin.getConfig().getInt("ah.tax-percent", 5);
        long tax = l.price() * taxPct / 100;
        long gain = l.price() - tax;
        plugin.eco.add(l.seller(), gain);
        give(p, l.item().clone());
        save();

        p.sendMessage(c("&aĐã mua &fx" + l.item().getAmount() + " &atừ &f" + l.sellerName()
                + " &avới giá &e" + fmt(l.price())));
        Player seller = Bukkit.getPlayer(l.seller());
        if (seller != null) {
            seller.sendMessage(c("&a" + p.getName() + " đã mua đồ của bạn: &e+" + fmt(gain)
                    + " &7(phí chợ " + fmt(tax) + ")"));
        }
        render(p, h);
    }

    private void give(Player p, ItemStack it) {
        for (ItemStack left : p.getInventory().addItem(it).values())
            p.getWorld().dropItemNaturally(p.getLocation(), left);
    }
}
