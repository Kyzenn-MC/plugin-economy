rootProject.name = "KyzenEconomy"
